# Real-Time ML Inference REST API & Capstone

A sentiment classification model served as a REST API using FastAPI.

## Files
- app.py: FastAPI service with /predict and /health endpoints
- model.pkl: trained TF-IDF and Logistic Regression pipeline
- requirements.txt: pinned dependencies
- Dockerfile: container build instructions
- test_app.py: API unit tests

## Run locally
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app:app --reload
```
Open http://127.0.0.1:8000/docs.

## Example request
```bash
curl -X POST http://127.0.0.1:8000/predict -H "Content-Type: application/json" -d '{"text":"The acting was wonderful"}'
```

## Tests
```bash
pytest -v
```

## Docker
```bash
docker build -t sentiment-api .
docker run --rm -p 8000:8000 sentiment-api
```

## Architecture
Client JSON -> FastAPI validation -> saved TF-IDF/logistic-regression pipeline -> prediction and class probabilities -> JSON response.

## Dataset limitation
The notebook uses a small illustrative dataset for a reproducible demonstration. Replace it with a larger representative labeled dataset before claiming real-world performance.
