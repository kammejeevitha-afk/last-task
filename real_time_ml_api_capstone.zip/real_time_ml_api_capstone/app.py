from pathlib import Path
import joblib
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

MODEL_PATH = Path(__file__).parent / "model.pkl"
if not MODEL_PATH.exists():
    raise RuntimeError(f"Model file not found: {MODEL_PATH}")
model = joblib.load(MODEL_PATH)

app = FastAPI(title="Sentiment Prediction API",
              description="Real-time positive/negative text inference API",
              version="1.0.0")

class PredictionRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=5000)

class PredictionResponse(BaseModel):
    text: str
    predicted_label: str
    probabilities: dict[str, float]

@app.get("/")
def root():
    return {"message": "Sentiment API is running", "docs": "/docs"}

@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": True}

@app.post("/predict", response_model=PredictionResponse)
def predict(request: PredictionRequest):
    text = request.text.strip()
    if not text:
        raise HTTPException(status_code=422, detail="Text must not be empty")
    prediction = int(model.predict([text])[0])
    probs = model.predict_proba([text])[0]
    probabilities = {
        ("negative" if int(label) == 0 else "positive"): round(float(prob), 6)
        for label, prob in zip(model.classes_, probs)
    }
    return {
        "text": text,
        "predicted_label": "positive" if prediction == 1 else "negative",
        "probabilities": probabilities,
    }
