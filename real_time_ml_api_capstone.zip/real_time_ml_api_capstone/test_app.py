from fastapi.testclient import TestClient
from app import app

client = TestClient(app)

def test_root():
    response = client.get("/")
    assert response.status_code == 200
    assert response.json()["docs"] == "/docs"

def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["model_loaded"] is True

def test_predict():
    response = client.post("/predict", json={"text": "A wonderful and enjoyable film"})
    assert response.status_code == 200
    body = response.json()
    assert body["predicted_label"] in ["positive", "negative"]
    assert set(body["probabilities"]) == {"positive", "negative"}

def test_empty_text():
    response = client.post("/predict", json={"text": "   "})
    assert response.status_code == 422
